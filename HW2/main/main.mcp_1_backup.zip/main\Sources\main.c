#include <hidef.h>      /* common defines and macros */
#include <mc9s12dp512.h>
#pragma LINK_INFO DERIVATIVE "mc9s12dp512"
unsigned int Tcount;


void main(void) {
  /* put your own code here */
  DDRT = DDRT | 0x10;
  TSCR1 = 0x80;
  TSCR2 = 0x00;
  TIOS = 0x20;
  TCTL1 = 0x04;
  
  while(1) {
   Tcount = TCNT ;
   Tcount = Tcount + 10000;
   TC5 = Tcount;
   while(!(TFLG1 & TFLG1_C5F_MASK));
   TFLG1 = TFLG1 | TFLG1_C5F_MASK;
    
  }


	EnableInterrupts;


  for(;;) {
    _FEED_COP(); /* feeds the dog */
  } /* loop forever */
  /* please make sure that you never leave main */
}
